import React, { useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import { Bed, Bath, Square, MapPin } from 'lucide-react';

interface PropertyCardProps {
  image: string;
  title: string;
  price: string;
  location: string;
  beds: number;
  baths: number;
  sqft: number;
  className?: string;
}

export function PropertyCard({
  image,
  title,
  price,
  location,
  beds,
  baths,
  sqft,
  className,
}: PropertyCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0.5, y: 0.5 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width;
    const y = (e.clientY - rect.top) / rect.height;
    setMousePosition({ x, y });
  };

  return (
    <div
      ref={cardRef}
      className={cn(
        'group relative bg-white rounded-2xl overflow-hidden shadow-lg transition-all duration-500',
        'hover:shadow-2xl hover:-translate-y-2',
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setMousePosition({ x: 0.5, y: 0.5 });
      }}
      onMouseMove={handleMouseMove}
    >
      {/* Image Container */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        
        {/* Overlay */}
        <div 
          className={cn(
            'absolute inset-0 bg-dark/40 transition-opacity duration-300',
            isHovered ? 'opacity-100' : 'opacity-0'
          )}
        />
        
        {/* Price Badge */}
        <div className="absolute top-4 left-4 bg-primary px-4 py-2 rounded-full">
          <span className="font-body font-semibold text-dark text-sm">{price}</span>
        </div>

        {/* View Details Button */}
        <div
          className={cn(
            'absolute inset-0 flex items-center justify-center transition-all duration-300',
            isHovered ? 'opacity-100' : 'opacity-0'
          )}
        >
          <button
            className="bg-white text-dark px-6 py-3 rounded-full font-body font-medium transform transition-transform duration-300 hover:scale-105"
            style={{
              transform: isHovered 
                ? `translate(${(mousePosition.x - 0.5) * 10}px, ${(mousePosition.y - 0.5) * 10}px)` 
                : 'translateY(20px)',
            }}
          >
            View Details
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-display text-xl font-semibold text-dark mb-2 group-hover:text-primary transition-colors">
          {title}
        </h3>
        
        <div className="flex items-center gap-1 text-muted-foreground mb-4">
          <MapPin size={16} />
          <span className="font-body text-sm">{location}</span>
        </div>

        {/* Features */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <Bed size={18} className="text-primary" />
            <span className="font-body text-sm text-dark">{beds} Beds</span>
          </div>
          <div className="flex items-center gap-2">
            <Bath size={18} className="text-primary" />
            <span className="font-body text-sm text-dark">{baths} Baths</span>
          </div>
          <div className="flex items-center gap-2">
            <Square size={18} className="text-primary" />
            <span className="font-body text-sm text-dark">{sqft} sqft</span>
          </div>
        </div>
      </div>
    </div>
  );
}
