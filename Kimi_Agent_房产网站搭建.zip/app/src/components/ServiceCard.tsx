import { useState } from 'react';
import { cn } from '@/lib/utils';
import type { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  className?: string;
}

export function ServiceCard({
  icon: Icon,
  title,
  description,
  className,
}: ServiceCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={cn(
        'relative p-8 bg-white border border-border rounded-2xl overflow-hidden transition-all duration-500',
        'hover:border-primary hover:shadow-xl',
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Background Fill Animation */}
      <div
        className={cn(
          'absolute inset-0 bg-primary transition-transform duration-500 origin-bottom-left',
          isHovered ? 'scale-100' : 'scale-0'
        )}
        style={{
          clipPath: 'polygon(0 100%, 100% 0, 100% 100%, 0 100%)',
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        {/* Icon */}
        <div
          className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-all duration-500',
            isHovered ? 'bg-dark' : 'bg-primary'
          )}
        >
          <Icon
            size={28}
            className={cn(
              'transition-all duration-500',
              isHovered ? 'text-primary rotate-[360deg]' : 'text-dark'
            )}
          />
        </div>

        {/* Title */}
        <h3
          className={cn(
            'font-display text-xl font-semibold mb-3 transition-colors duration-300',
            isHovered ? 'text-dark' : 'text-dark'
          )}
        >
          {title}
        </h3>

        {/* Description */}
        <p
          className={cn(
            'font-body text-sm leading-relaxed transition-colors duration-300',
            isHovered ? 'text-dark/80' : 'text-muted-foreground'
          )}
        >
          {description}
        </p>
      </div>
    </div>
  );
}
