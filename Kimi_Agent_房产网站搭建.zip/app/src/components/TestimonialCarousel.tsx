import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import gsap from 'gsap';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  image: string;
}

interface TestimonialCarouselProps {
  testimonials: Testimonial[];
  className?: string;
}

export function TestimonialCarousel({ testimonials, className }: TestimonialCarouselProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const goToSlide = (index: number) => {
    if (isAnimating || index === activeIndex) return;
    setIsAnimating(true);

    const direction = index > activeIndex ? 1 : -1;
    
    gsap.to(contentRef.current, {
      opacity: 0,
      x: -50 * direction,
      duration: 0.3,
      onComplete: () => {
        setActiveIndex(index);
        gsap.fromTo(
          contentRef.current,
          { opacity: 0, x: 50 * direction },
          { 
            opacity: 1, 
            x: 0, 
            duration: 0.5,
            onComplete: () => setIsAnimating(false)
          }
        );
      },
    });
  };

  const nextSlide = () => {
    const next = (activeIndex + 1) % testimonials.length;
    goToSlide(next);
  };

  const prevSlide = () => {
    const prev = (activeIndex - 1 + testimonials.length) % testimonials.length;
    goToSlide(prev);
  };

  // Auto-play
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isAnimating) {
        nextSlide();
      }
    }, 6000);

    return () => clearInterval(interval);
  }, [activeIndex, isAnimating]);

  const currentTestimonial = testimonials[activeIndex];

  return (
    <div
      ref={containerRef}
      className={cn('relative', className)}
    >
      {/* Main Content */}
      <div className="relative overflow-hidden">
        <div ref={contentRef} className="flex flex-col items-center text-center">
          {/* Quote Icon */}
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mb-8">
            <Quote size={32} className="text-white" />
          </div>

          {/* Testimonial Text */}
          <blockquote className="font-display text-2xl md:text-3xl lg:text-4xl text-white leading-relaxed mb-8 max-w-3xl">
            "{currentTestimonial.content}"
          </blockquote>

          {/* Author */}
          <div className="flex items-center gap-4">
            <img
              src={currentTestimonial.image}
              alt={currentTestimonial.name}
              className="w-16 h-16 rounded-full object-cover border-2 border-white"
            />
            <div className="text-left">
              <h4 className="font-display text-lg font-semibold text-white">
                {currentTestimonial.name}
              </h4>
              <p className="font-body text-sm text-white/70">
                {currentTestimonial.role}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-center gap-4 mt-12">
        <button
          onClick={prevSlide}
          disabled={isAnimating}
          className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors disabled:opacity-50"
        >
          <ChevronLeft size={24} />
        </button>

        {/* Dots */}
        <div className="flex gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={cn(
                'w-3 h-3 rounded-full transition-all duration-300',
                index === activeIndex
                  ? 'bg-white w-8'
                  : 'bg-white/40 hover:bg-white/60'
              )}
            />
          ))}
        </div>

        <button
          onClick={nextSlide}
          disabled={isAnimating}
          className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white hover:bg-white/30 transition-colors disabled:opacity-50"
        >
          <ChevronRight size={24} />
        </button>
      </div>
    </div>
  );
}
