import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { cn } from '@/lib/utils';

gsap.registerPlugin(ScrollTrigger);

interface TextRevealProps {
  children: string;
  className?: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span';
  delay?: number;
  splitBy?: 'words' | 'chars' | 'lines';
}

export function TextReveal({
  children,
  className,
  as: Component = 'span',
  delay = 0,
  splitBy = 'words',
}: TextRevealProps) {
  const containerRef = useRef<HTMLElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || hasAnimated.current) return;

    const text = children;
    let elements: string[] = [];
    
    if (splitBy === 'words') {
      elements = text.split(' ');
    } else if (splitBy === 'chars') {
      elements = text.split('');
    } else {
      elements = [text];
    }

    container.innerHTML = elements
      .map((el, i) => 
        `<span class="inline-block overflow-hidden">
          <span class="inline-block transform translate-y-full opacity-0 text-reveal-item" style="transition-delay: ${i * 0.05}s">${el === ' ' ? '&nbsp;' : el}</span>
        </span>`
      )
      .join(splitBy === 'chars' ? '' : ' ');

    const items = container.querySelectorAll('.text-reveal-item');
    
    const trigger = ScrollTrigger.create({
      trigger: container,
      start: 'top 80%',
      onEnter: () => {
        if (hasAnimated.current) return;
        hasAnimated.current = true;
        
        gsap.to(items, {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: splitBy === 'chars' ? 0.02 : 0.05,
          delay,
          ease: 'expo.out',
        });
      },
    });

    return () => {
      trigger.kill();
    };
  }, [children, delay, splitBy]);

  return (
    <Component
      ref={containerRef as any}
      className={cn('inline-block', className)}
    >
      {children}
    </Component>
  );
}

interface AnimatedHeadingProps {
  children: string;
  className?: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4';
}

export function AnimatedHeading({ children, className, as: Component = 'h2' }: AnimatedHeadingProps) {
  const headingRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const heading = headingRef.current;
    if (!heading) return;

    gsap.fromTo(
      heading,
      { y: 60, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: heading,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      }
    );
  }, []);

  return (
    <Component
      ref={headingRef as any}
      className={cn(className)}
    >
      {children}
    </Component>
  );
}
