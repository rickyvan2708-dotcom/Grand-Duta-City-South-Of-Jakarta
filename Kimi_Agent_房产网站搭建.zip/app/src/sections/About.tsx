import { useEffect, useRef } from 'react';

export function About() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative py-16 lg:py-24 bg-white"
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Heading */}
          <h2 className="reveal opacity-0 translate-y-8 transition-all duration-700 text-2xl sm:text-3xl lg:text-4xl font-bold text-green-800 mb-6">
            BETTER LIVING FOR GENERATIONS
          </h2>

          {/* Description */}
          <p className="reveal opacity-0 translate-y-8 transition-all duration-700 delay-200 text-base sm:text-lg text-gray-600 leading-relaxed">
            Grand Duta City South of Jakarta merupakan hunian impian masa depan dan berada di lokasi strategis Selatan Jakarta. Grand Duta City South of Jakarta memenuhi kebutuhan hunianmu di masa kini hingga untuk masa depan nanti.
          </p>
        </div>
      </div>

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}</style>
    </section>
  );
}
