import { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { AnimatedHeading } from '@/components/TextReveal';
import { ArrowUpRight, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

gsap.registerPlugin(ScrollTrigger);

const blogPosts = [
  {
    id: 1,
    title: '10 Tips for First-Time Home Buyers',
    excerpt: 'Essential advice for navigating the property market as a first-time buyer. Learn about mortgages, inspections, and negotiation strategies.',
    image: '/images/property-1.jpg',
    date: 'Jan 15, 2024',
    category: 'Buying Guide',
    featured: true,
  },
  {
    id: 2,
    title: 'Market Trends 2024',
    excerpt: 'An in-depth analysis of the real estate market trends shaping the industry this year.',
    image: '/images/property-2.jpg',
    date: 'Jan 10, 2024',
    category: 'Market Analysis',
    featured: false,
  },
  {
    id: 3,
    title: 'Renovation ROI Guide',
    excerpt: 'Discover which home improvements offer the best return on investment.',
    image: '/images/property-3.jpg',
    date: 'Jan 5, 2024',
    category: 'Investment',
    featured: false,
  },
];

function BlogCard({
  post,
  className,
  featured = false,
}: {
  post: typeof blogPosts[0];
  className?: string;
  featured?: boolean;
}) {
  const [isHovered, setIsHovered] = useState(false);
  const imageRef = useRef<HTMLImageElement>(null);

  return (
    <article
      className={cn(
        'group relative bg-white rounded-2xl overflow-hidden shadow-lg transition-all duration-500',
        'hover:shadow-xl',
        featured ? 'h-full' : '',
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image */}
      <div className={cn('relative overflow-hidden', featured ? 'h-72 lg:h-80' : 'h-48')}>
        <img
          ref={imageRef}
          src={post.image}
          alt={post.title}
          className={cn(
            'w-full h-full object-cover transition-transform duration-700',
            isHovered && 'scale-110'
          )}
        />
        <div className={cn(
          'absolute inset-0 bg-dark/20 transition-opacity duration-300',
          isHovered ? 'opacity-100' : 'opacity-0'
        )} />
        
        {/* Category Badge */}
        <div className="absolute top-4 left-4 bg-primary px-3 py-1 rounded-full">
          <span className="font-body text-xs font-medium text-dark">{post.category}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Date */}
        <div className="flex items-center gap-2 text-muted-foreground mb-3">
          <Calendar size={14} />
          <span className="font-body text-xs">{post.date}</span>
        </div>

        {/* Title */}
        <h3 className={cn(
          'font-display font-semibold text-dark mb-3 group-hover:text-primary transition-colors',
          featured ? 'text-2xl' : 'text-lg'
        )}>
          {post.title}
        </h3>

        {/* Excerpt */}
        <p className="font-body text-sm text-muted-foreground leading-relaxed mb-4">
          {post.excerpt}
        </p>

        {/* Read More */}
        <div className="flex items-center gap-2 text-dark font-body text-sm font-medium">
          <span className="relative">
            Read More
            <span className={cn(
              'absolute -bottom-1 left-0 h-0.5 bg-primary transition-all duration-300',
              isHovered ? 'w-full' : 'w-0'
            )} />
          </span>
          <ArrowUpRight 
            size={16} 
            className={cn(
              'transition-transform duration-300',
              isHovered && 'translate-x-1 -translate-y-1'
            )} 
          />
        </div>
      </div>
    </article>
  );
}

export function Blog() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Grid animation
      gsap.fromTo(
        gridRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: gridRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const featuredPost = blogPosts.find(post => post.featured);
  const otherPosts = blogPosts.filter(post => !post.featured);

  return (
    <section
      ref={sectionRef}
      id="blog"
      className="relative py-24 lg:py-32 bg-light"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 lg:mb-16">
          <div>
            <span className="font-body text-sm text-primary uppercase tracking-widest mb-4 block">
              Latest News
            </span>
            <AnimatedHeading
              as="h2"
              className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-dark"
            >
              Latest Insights
            </AnimatedHeading>
          </div>
          <button className="group flex items-center gap-2 text-dark font-body font-medium mt-4 lg:mt-0">
            View All Articles
            <ArrowUpRight 
              size={20} 
              className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" 
            />
          </button>
        </div>

        {/* Blog Grid - Magazine Layout */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 lg:grid-cols-5 gap-8"
        >
          {/* Featured Post */}
          {featuredPost && (
            <div className="lg:col-span-3">
              <BlogCard post={featuredPost} featured />
            </div>
          )}

          {/* Other Posts */}
          <div className="lg:col-span-2 flex flex-col gap-8">
            {otherPosts.map((post) => (
              <BlogCard key={post.id} post={post} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
