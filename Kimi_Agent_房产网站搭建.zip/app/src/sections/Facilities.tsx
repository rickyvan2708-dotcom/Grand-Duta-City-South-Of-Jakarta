import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const facilities = [
  {
    id: 1,
    name: 'The Beach',
    image: '/images/facility-beach.jpg',
  },
  {
    id: 2,
    name: 'Cluster Private Pool',
    image: '/images/facility-pool.jpg',
  },
  {
    id: 3,
    name: 'Central Park',
    image: '/images/facility-park.jpg',
  },
  {
    id: 4,
    name: 'Outdoor Playground',
    image: '/images/facility-playground.jpg',
  },
];

export function Facilities() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % facilities.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const goToPrevious = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev - 1 + facilities.length) % facilities.length);
  };

  const goToNext = () => {
    setIsAutoPlaying(false);
    setCurrentIndex((prev) => (prev + 1) % facilities.length);
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="facilities"
      className="relative py-16 lg:py-24 bg-gray-50"
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        {/* Heading */}
        <h2 className="reveal opacity-0 translate-y-8 transition-all duration-700 text-2xl sm:text-3xl lg:text-4xl font-bold text-green-800 text-center mb-4">
          FACILITIES
        </h2>
        <p className="reveal opacity-0 translate-y-8 transition-all duration-700 delay-200 text-base text-gray-600 text-center max-w-3xl mx-auto mb-12">
          Grand Duta City South of Jakarta akan menjadi jawaban sempurna untuk memenuhi kebutuhan hunianmu dan keluargamu di masa kini hingga di masa depan nanti.
        </p>

        {/* Carousel */}
        <div className="reveal opacity-0 translate-y-8 transition-all duration-700 delay-300 relative max-w-5xl mx-auto">
          <div className="relative overflow-hidden rounded-2xl shadow-2xl aspect-video">
            {facilities.map((facility, index) => (
              <div
                key={facility.id}
                className={`absolute inset-0 transition-opacity duration-500 ${
                  index === currentIndex ? 'opacity-100' : 'opacity-0'
                }`}
              >
                <img
                  src={facility.image}
                  alt={facility.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-8 left-8 right-8">
                  <h3 className="text-2xl sm:text-3xl font-bold text-white">
                    {facility.name}
                  </h3>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
          >
            <ChevronLeft className="w-6 h-6 text-green-800" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
          >
            <ChevronRight className="w-6 h-6 text-green-800" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-6">
            {facilities.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setIsAutoPlaying(false);
                  setCurrentIndex(index);
                }}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentIndex
                    ? 'bg-green-700 w-8'
                    : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}</style>
    </section>
  );
}
