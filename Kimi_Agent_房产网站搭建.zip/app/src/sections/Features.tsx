import { useEffect, useRef } from 'react';
import { Sun, Smartphone } from 'lucide-react';

const features = [
  {
    icon: Sun,
    title: 'HEALTHY HOME',
    description: 'Direct Sunlight with an Excellent Airflow for Your Family',
    color: 'from-orange-400 to-yellow-400',
  },
  {
    icon: Smartphone,
    title: 'SMART HOME',
    description: 'Control Your Home with a Smart Phone',
    color: 'from-blue-400 to-cyan-400',
  },
];

export function Features() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const openWhatsApp = () => {
    window.open('https://wa.me/6281234567890', '_blank');
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-16 lg:py-24 bg-gray-50"
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="reveal opacity-0 translate-y-8 transition-all duration-700"
              style={{ transitionDelay: `${(index + 1) * 200}ms` }}
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow text-center">
                <div className={`w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br ${feature.color} flex items-center justify-center`}>
                  <feature.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-green-800 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="reveal opacity-0 translate-y-8 transition-all duration-700 delay-500 text-center">
          <p className="text-lg sm:text-xl text-gray-700 mb-6">
            Segera miliki hunian impian-mu dan jangan lewatkan promonya!
          </p>
          <button
            onClick={openWhatsApp}
            className="bg-green-700 hover:bg-green-800 text-white px-8 py-3 rounded-lg font-medium transition-colors shadow-lg hover:shadow-xl"
          >
            Hubungi Kami Sekarang
          </button>
        </div>
      </div>

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}</style>
    </section>
  );
}
