import { MapPin, Instagram, Facebook } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Marketing Gallery Section */}
      <div className="py-16 lg:py-20 bg-gray-800">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-8">
              MARKETING GALLERY
            </h3>
            <div className="flex items-start justify-center gap-3 text-gray-300">
              <MapPin className="w-6 h-6 flex-shrink-0 mt-1" />
              <div className="text-left">
                <p className="font-medium text-white">Grand Duta City – South of Jakarta.</p>
                <p>Jl. Boulevard GDC,</p>
                <p>Kec. Parung, Bogor,</p>
                <p>Jawa Barat 16330</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Developed By & Social */}
      <div className="py-8 bg-gray-900">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Developed By */}
            <div className="text-center md:text-left">
              <p className="text-sm text-gray-400 mb-2">DEVELOPED BY</p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <span className="text-green-800 font-bold text-lg">G</span>
                </div>
                <span className="text-white font-medium">Grand Duta City</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              <a
                href="https://www.instagram.com/granddutacity.soj/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
              >
                <Instagram className="w-5 h-5 text-white" />
              </a>
              <a
                href="https://www.facebook.com/granddutacity.soj.official"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:scale-110 transition-transform"
              >
                <Facebook className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="py-4 bg-gray-950 border-t border-gray-800">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
          <p className="text-center text-sm text-gray-500">
            Copyright © 2024 Grand Duta City South Of Jakarta
          </p>
        </div>
      </div>
    </footer>
  );
}
