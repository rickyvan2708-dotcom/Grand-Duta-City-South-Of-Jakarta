import { useEffect, useRef } from 'react';

export function Hero() {
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Parallax effect
    const handleScroll = () => {
      if (heroRef.current) {
        const scrolled = window.scrollY;
        const parallaxElements = heroRef.current.querySelectorAll('.parallax');
        parallaxElements.forEach((el) => {
          (el as HTMLElement).style.transform = `translateY(${scrolled * 0.3}px)`;
        });
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const openWhatsApp = () => {
    window.open('https://wa.me/6281234567890', '_blank');
  };

  return (
    <section
      ref={heroRef}
      id="home"
      className="relative min-h-screen w-full overflow-hidden pt-24"
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Grand Duta City"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-12 lg:py-20">
        <div className="max-w-2xl">
          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-green-800 leading-tight mb-4">
            Hunian Mewah
          </h1>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-green-800 leading-tight mb-6">
            Tipe Malta & Tipe Tuscan
          </h2>

          {/* Subheading */}
          <p className="text-lg sm:text-xl text-green-700 mb-2">
            Rasakan Keanggunan dengan Ceiling Tinggi!
          </p>
          <p className="text-base sm:text-lg text-gray-600 mb-8">
            Ciptakan momen istimewa di rumah mewah Anda!
          </p>

          {/* Promo Badges */}
          <div className="flex flex-wrap gap-4 mb-6">
            {/* Badge 1 */}
            <div className="relative">
              <div className="bg-green-700 text-white px-4 py-1 text-xs font-medium rounded-t-lg">
                CICILAN KPR MULAI
              </div>
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-green-900 px-6 py-3 rounded-b-lg rounded-tr-lg">
                <span className="text-4xl font-bold">2,5</span>
                <span className="text-xl font-bold ml-1">JT</span>
                <span className="text-sm block -mt-1">-an/bln*</span>
              </div>
            </div>

            {/* Badge 2 */}
            <div className="relative">
              <div className="bg-green-700 text-white px-4 py-1 text-xs font-medium rounded-t-lg">
                BAYAR
              </div>
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-green-900 px-6 py-3 rounded-b-lg rounded-tr-lg flex items-center gap-3">
                <div>
                  <span className="text-4xl font-bold">5</span>
                  <span className="text-xl font-bold">JT</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold block">LANGSUNG</span>
                  <span className="text-lg font-bold">AKAD</span>
                </div>
              </div>
            </div>
          </div>

          {/* KPR Safe Banner */}
          <div className="bg-gradient-to-r from-green-700 to-green-600 rounded-xl p-4 mb-4 max-w-md">
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0">
                <div className="text-3xl font-black text-yellow-400 italic transform -skew-x-6">
                  KPR
                </div>
                <div className="text-3xl font-black text-yellow-400 italic transform -skew-x-6 -mt-2">
                  SAFE
                </div>
              </div>
              <div className="text-white">
                <p className="text-sm font-medium">BAYAR <span className="text-yellow-400 font-bold">5 JUTA LANGSUNG AKAD</span></p>
                <p className="text-xs mt-1">Subsidi Bunga & Angsuran dari Developer*</p>
                <p className="text-xs">FREE Biaya Surat-Surat*</p>
              </div>
            </div>
          </div>

          {/* Terms */}
          <p className="text-xs text-gray-500 mb-6">**Syarat dan Ketentuan Berlaku</p>

          {/* CTA Button */}
          <button
            onClick={openWhatsApp}
            className="bg-green-700 hover:bg-green-800 text-white px-8 py-3 rounded-lg font-medium transition-colors shadow-lg hover:shadow-xl"
          >
            Hubungi Kami Sekarang
          </button>
        </div>
      </div>
    </section>
  );
}
