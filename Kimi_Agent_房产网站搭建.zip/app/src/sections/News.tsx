import { useEffect, useRef } from 'react';
import { Calendar, ArrowRight } from 'lucide-react';

const newsItems = [
  {
    id: 1,
    title: 'Grand Duta City South of Jakarta, Hunian Modern dengan Fasilitas Super Lengkap',
    category: 'News',
    date: '28 July 2025',
    excerpt: 'Menemukan hunian nyaman di kawasan Selatan Jakarta kini semakin mudah. Grand Duta City South of Jakarta hadir sebagai pilihan hunian modern yang menaw...',
    image: '/images/news-1.jpg',
  },
  {
    id: 2,
    title: 'Simak Tips Ini Agar Gen Z Bisa Punya Rumah di Usia Muda',
    category: 'News',
    date: '18 July 2025',
    excerpt: 'Memiliki rumah sendiri di usia muda terdengar seperti impian yang sulit dicapai, apalagi di tengah harga properti yang terus naik dan biaya hidup yang...',
    image: '/images/news-2.jpg',
  },
  {
    id: 3,
    title: 'Alasan Grand Duta City South of Jakarta Cocok Jadi Rumah Pertama Kamu',
    category: 'News',
    date: '14 July 2025',
    excerpt: 'Memilih rumah pertama bukan cuma soal bangunan — tapi juga soal gaya hidup, kenyamanan, dan potensi jangka panjang. Untuk kamu yang sedang cari hunian...',
    image: '/images/news-3.jpg',
  },
];

export function News() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="news"
      className="relative py-16 lg:py-24 bg-white"
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        {/* Heading */}
        <h2 className="reveal opacity-0 translate-y-8 transition-all duration-700 text-2xl sm:text-3xl lg:text-4xl font-bold text-green-800 text-center mb-12">
          NEWS & UPDATE
        </h2>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {newsItems.map((news, index) => (
            <article
              key={news.id}
              className="reveal opacity-0 translate-y-8 transition-all duration-700 group cursor-pointer"
              style={{ transitionDelay: `${(index + 1) * 150}ms` }}
            >
              <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                {/* Image */}
                <div className="aspect-video overflow-hidden">
                  <img
                    src={news.image}
                    alt={news.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Content */}
                <div className="p-6">
                  {/* Meta */}
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <span className="text-green-700 font-medium">{news.category}</span>
                    <span>|</span>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{news.date}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-gray-800 mb-3 line-clamp-2 group-hover:text-green-700 transition-colors">
                    {news.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                    {news.excerpt}
                  </p>

                  {/* Read More */}
                  <div className="flex items-center gap-2 text-green-700 font-medium text-sm group-hover:gap-3 transition-all">
                    <span>Read More</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* More News Button */}
        <div className="reveal opacity-0 translate-y-8 transition-all duration-700 delay-500 text-center mt-10">
          <button className="inline-flex items-center gap-2 text-green-700 font-medium hover:gap-3 transition-all">
            <span>More News</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </section>
  );
}
