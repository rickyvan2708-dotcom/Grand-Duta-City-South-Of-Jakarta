import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { PropertyCard } from '@/components/PropertyCard';
import { AnimatedHeading } from '@/components/TextReveal';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const properties = [
  {
    id: 1,
    image: '/images/property-1.jpg',
    title: 'Cozy Cottage',
    price: '$500/month',
    location: 'Beverly Hills, CA',
    beds: 3,
    baths: 2,
    sqft: 1200,
  },
  {
    id: 2,
    image: '/images/property-2.jpg',
    title: 'Modern Loft',
    price: '$700/month',
    location: 'Downtown LA, CA',
    beds: 2,
    baths: 2,
    sqft: 1500,
  },
  {
    id: 3,
    image: '/images/property-3.jpg',
    title: 'Beach House',
    price: '$900/month',
    location: 'Malibu, CA',
    beds: 4,
    baths: 3,
    sqft: 2200,
  },
];

export function Properties() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current?.children;
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 80, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="properties"
      className="relative py-24 lg:py-32 bg-light"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12 lg:mb-16">
          <div>
            <span className="font-body text-sm text-primary uppercase tracking-widest mb-4 block">
              Featured Listings
            </span>
            <AnimatedHeading
              as="h2"
              className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-dark"
            >
              Our Properties
            </AnimatedHeading>
          </div>
          <p className="font-body text-muted-foreground max-w-md mt-4 lg:mt-0">
            Handpicked exclusive properties for you. Discover your dream home from our curated collection.
          </p>
        </div>

        {/* Property Cards Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {properties.map((property) => (
            <PropertyCard
              key={property.id}
              {...property}
            />
          ))}
        </div>

        {/* View All Button */}
        <div className="flex justify-center mt-12">
          <button className="group flex items-center gap-2 bg-dark text-white px-8 py-4 rounded-full font-body font-medium hover:bg-dark/90 transition-colors">
            View All Properties
            <ArrowRight 
              size={20} 
              className="transition-transform group-hover:translate-x-1" 
            />
          </button>
        </div>
      </div>
    </section>
  );
}
