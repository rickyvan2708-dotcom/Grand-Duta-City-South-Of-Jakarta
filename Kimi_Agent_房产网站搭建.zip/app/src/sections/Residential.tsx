import { useEffect, useRef } from 'react';

const clusters = [
  {
    name: 'CLUSTER LADERA',
    properties: [
      {
        name: 'TUSCAN',
        type: 'TYPE 66',
        landSize: '72',
        buildingSize: '66',
        image: '/images/property-tuscan.jpg',
      },
      {
        name: 'MALTA',
        type: 'TYPE 47',
        landSize: '72',
        buildingSize: '47',
        image: '/images/property-malta.jpg',
      },
    ],
  },
  {
    name: 'CLUSTER CASCADA',
    properties: [
      {
        name: 'ALEXANDRA',
        type: 'TYPE 88',
        landSize: '105',
        buildingSize: '88',
        image: '/images/property-alexandra.jpg',
      },
      {
        name: 'AIRA+',
        type: 'TYPE 42',
        landSize: '60',
        buildingSize: '42',
        image: '/images/property-aira.jpg',
      },
    ],
  },
  {
    name: 'CLUSTER MANOA & VICTORIA',
    properties: [
      {
        name: 'MANOA',
        type: 'TYPE 58',
        landSize: '60',
        buildingSize: '58',
        image: '/images/property-manoa.jpg',
      },
      {
        name: 'VICTORIA',
        type: 'TYPE 69',
        landSize: '72',
        buildingSize: '69',
        image: '/images/property-victoria.jpg',
      },
    ],
  },
];

export function Residential() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="residential"
      className="relative py-16 lg:py-24 bg-white"
    >
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        {clusters.map((cluster) => (
          <div key={cluster.name} className="mb-16 last:mb-0">
            {/* Cluster Name */}
            <h2 className="reveal opacity-0 translate-y-8 transition-all duration-700 text-2xl sm:text-3xl font-bold text-green-800 text-center mb-10">
              {cluster.name}
            </h2>

            {/* Properties Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {cluster.properties.map((property, propertyIndex) => (
                <div
                  key={property.name}
                  className="reveal opacity-0 translate-y-8 transition-all duration-700 group"
                  style={{ transitionDelay: `${(propertyIndex + 1) * 150}ms` }}
                >
                  <div className="relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-shadow">
                    {/* Image */}
                    <div className="aspect-[4/3] overflow-hidden">
                      <img
                        src={property.image}
                        alt={property.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>

                    {/* Overlay Info */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-6">
                      <h3 className="text-2xl font-bold text-white mb-1">
                        {property.name}
                      </h3>
                      <p className="text-lg text-yellow-400 font-medium mb-4">
                        {property.type}
                      </p>

                      {/* Specs */}
                      <div className="flex gap-6">
                        <div>
                          <p className="text-xs text-gray-300 uppercase tracking-wider">Land Size</p>
                          <p className="text-white font-medium">
                            {property.landSize}M<sup>2</sup>
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-300 uppercase tracking-wider">Building Size</p>
                          <p className="text-white font-medium">
                            {property.buildingSize}M<sup>2</sup>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        .animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}</style>
    </section>
  );
}
