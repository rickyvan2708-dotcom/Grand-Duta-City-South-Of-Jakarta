import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ServiceCard } from '@/components/ServiceCard';
import { AnimatedHeading } from '@/components/TextReveal';
import { Building2, ClipboardList, TrendingUp, Calculator } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Building2,
    title: 'Property Listings',
    description: 'Browse our extensive collection of premium properties. From cozy apartments to luxury villas, find the perfect match for your lifestyle.',
  },
  {
    icon: ClipboardList,
    title: 'Property Management',
    description: 'Comprehensive property management services including tenant screening, rent collection, maintenance coordination, and financial reporting.',
  },
  {
    icon: TrendingUp,
    title: 'Investment Opportunities',
    description: 'Expert guidance on real estate investments. We analyze market trends and identify high-potential properties for maximum returns.',
  },
  {
    icon: Calculator,
    title: 'Property Valuation',
    description: 'Accurate property valuations using advanced market analysis. Get the true value of your property for buying, selling, or refinancing.',
  },
];

export function Services() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const linesRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Grid lines draw animation
      const lines = linesRef.current?.querySelectorAll('line');
      if (lines) {
        gsap.fromTo(
          lines,
          { strokeDashoffset: 1000 },
          {
            strokeDashoffset: 0,
            duration: 1.5,
            ease: 'power2.inOut',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Cards animation
      const cards = gridRef.current?.children;
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 50, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 65%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="relative py-24 lg:py-32 bg-light"
    >
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="font-body text-sm text-primary uppercase tracking-widest mb-4 block">
            What We Offer
          </span>
          <AnimatedHeading
            as="h2"
            className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-dark"
          >
            Our Services
          </AnimatedHeading>
        </div>

        {/* Services Grid */}
        <div className="relative">
          {/* Decorative Grid Lines */}
          <svg
            ref={linesRef}
            className="absolute inset-0 w-full h-full pointer-events-none hidden lg:block"
            style={{ zIndex: 0 }}
          >
            <line
              x1="50%"
              y1="0"
              x2="50%"
              y2="100%"
              stroke="#1a1a1a"
              strokeWidth="1"
              strokeDasharray="1000"
              strokeDashoffset="1000"
              opacity="0.1"
            />
            <line
              x1="0"
              y1="50%"
              x2="100%"
              y2="50%"
              stroke="#1a1a1a"
              strokeWidth="1"
              strokeDasharray="1000"
              strokeDashoffset="1000"
              opacity="0.1"
            />
          </svg>

          {/* Cards Grid */}
          <div
            ref={gridRef}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 relative z-10"
          >
            {services.map((service) => (
              <ServiceCard
                key={service.title}
                {...service}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
