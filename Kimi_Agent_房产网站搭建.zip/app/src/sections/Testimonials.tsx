import { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TestimonialCarousel } from '@/components/TestimonialCarousel';
import { AnimatedHeading } from '@/components/TextReveal';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'Home Buyer',
    content: 'Amazing service! Found my dream home in just a few weeks. The team was incredibly professional and attentive to all my needs.',
    image: '/images/testimonial-1.jpg',
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Property Investor',
    content: 'Professional and dedicated team. They helped me build a diverse property portfolio with excellent returns. Highly recommend!',
    image: '/images/testimonial-2.jpg',
  },
  {
    id: 3,
    name: 'Emily Davis',
    role: 'First-time Buyer',
    content: 'Made the whole process seamless and stress-free. As a first-time buyer, I felt supported every step of the way.',
    image: '/images/testimonial-3.jpg',
  },
];

export function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      className="relative py-24 lg:py-32 bg-secondary overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="w-full px-6 lg:px-12 relative z-10">
        <div ref={contentRef}>
          {/* Header */}
          <div className="text-center mb-16">
            <span className="font-body text-sm text-dark/60 uppercase tracking-widest mb-4 block">
              Client Stories
            </span>
            <AnimatedHeading
              as="h2"
              className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-dark"
            >
              What Our Clients Say
            </AnimatedHeading>
          </div>

          {/* Testimonial Carousel */}
          <TestimonialCarousel testimonials={testimonials} />
        </div>
      </div>
    </section>
  );
}
